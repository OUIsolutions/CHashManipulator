
## Criei minha própria Lib Declarativa para validaçao de dados, e o que aprendi com isso 

na semana retrasada, meu chefe me pediu pra construir uma api rest com mais ou menos 40 rotas
( o que considero bem pequena), não tenho muita prática com apis, e normalmente sempre lidei direto com sockets
toda vez que tinha que fazer comunicação web, mas encarei o desafio e comecei a fazer a api 
e me deparei com um problema que estava me incomodando muito: o excesso de ifs para validar entrada de dados.

Então procurei no mercado se já existe algum tipo de solução pra 