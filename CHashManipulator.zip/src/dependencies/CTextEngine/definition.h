
#include "CTextStack/admnistrative_methods.c"
#include "CTextStack/algo_methods.c"
#include "CTextStack/constructors.c"
#include "CTextStack/parsers.c"
#include "CTextStack/render_methods.c"


#include "extras/extras.c"
#include "CTextArray/CTextArray.c"
#include "CTextNamespace/definition.h"
