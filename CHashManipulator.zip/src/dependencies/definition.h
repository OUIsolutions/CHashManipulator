

#ifndef cJSON__h
#define cJSON__h
    #include "cJSON/cJSON.c"
#endif
#ifndef CTEXTENGINE_H
#define CTEXTENGINE_H
#include "CTextEngine/definition.h"
#endif
