

double  CHash_toNumber(CHash *element);


int CHash_convert_toNumber(CHash *self);

double  CHash_toNumber_converting(CHash *self);


void CHash_set_Number(CHash *self,double  value);


CHash * newCHashNumber(double value);
