

bool CHash_toBool(CHash *element);

int CHash_convert_toBool(CHash *self);

bool CHash_toBool_converting(CHash *self);


void CHash_set_Bool(CHash *self, bool value);


CHash * newCHashBool(bool value);
