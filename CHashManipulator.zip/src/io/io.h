

char *privateCHash_read_file(const char *filename);

int privateCHash_write_file(const char *filename, const char *value);